/**
 * 
 */
package com.mick88.notepad.NotePad;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Base64;
import android.widget.ImageView;

//import com.mick88.notepad.NotepadApplication;
import com.mick88.notepad.R;
//import com.mick88.notepad.MainViewList.LinkListDialog;
//import com.mick88.notepad.MainViewList.LinkListDialog.LinkListener;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Michal
 * 
 */
public class NoteActions implements Serializable
{
	private String text;
	private Bitmap setImage;
	String fileName = "";
	NoteManager noteManager = null;
	List<String> hyperlinks = new ArrayList<String>();

	public static final int BUFFER_SIZE = 512;

	public NoteActions(NoteManager noteManager) {
		this.noteManager = noteManager;
		this.text = "";
	}

	public NoteActions(NoteManager noteManager, String content,Bitmap bitmap) {
		this(noteManager);
		if (content == null)
			setText("");
		else
			setText(content);
		if(bitmap==null)
			setBitmap(null);
		else
			setBitmap(bitmap);
	}

	public NoteActions(NoteManager noteManager, CharSequence content,Bitmap bitmap) {
		this(noteManager, content.toString(),bitmap);
	}

	public String getText()
	{
		return text;
	}
	public Bitmap getBitmap() { return setImage;}

	/*private void findHyperlinks()//me
	{
		hyperlinks.clear();
		String[] words = this.text.toLowerCase(Locale.getDefault()).split("[\\s]");
		for (String word : words)
		{
			if (word.startsWith("http://") || word.startsWith("https://") || word.startsWith("www."))
			{
				if (word.startsWith("www.")) word = "http://"+word;
				hyperlinks.add(word.trim());
			}
		}
	}
*/
	/**
	 * Gets the list of hyperlinks found in the text
	 */
	/*public List<String> getHyperlinks()
	{
		return hyperlinks;
	} // me
*/
	public void setText(String t)
	{
		this.text = t;
		//findHyperlinks();me
	}
	public void setBitmap(Bitmap bitmap)
	{
		setImage=bitmap;
	}

	//public void setImage()
	public void appendText(String t)
	{
		setText(text.concat(t));
	}

	public String getStart(int numberCharacters, boolean ignoreNewline,
			boolean addEllipsis)
	{
		String s = ignoreNewline ? text : text.trim();
		int end = Math.min(numberCharacters, s.length());
		if (ignoreNewline == false)
		{
			int nlPos = s.indexOf('\n');
			if (nlPos > 0)
			{
				end = Math.min(end, nlPos);
			}
		}
		return addEllipsis ? s.substring(0, end) + "�" : s.substring(0, end);
	}

	public String toString()
	{
		return getStart(100, false, false);
	}

	public int getID()
	{
		return noteManager.noteActions.indexOf(this);
	}

	void delete(Context context)
	{
		if (TextUtils.isEmpty(fileName) == false)
		{
			context.deleteFile(fileName);
		}
	}

	/*public void popupHyperlinks(final ActionBarActivity activity) //me
	{
		if (hyperlinks.isEmpty()) return;
		
		LinkListDialog dialog = new LinkListDialog();
		dialog.setHyperlinks(this.hyperlinks);
		dialog.setLinkListener(new LinkListener()
		{
			public void onLinkClicked(String url)
			{
				((NotepadApplication)activity.getApplication()).openLink(url);
			}
		});
		dialog.show(activity.getSupportFragmentManager(), "Link selector");
	}

	public void copyToClipboard(NotepadApplication application)// me
	{
		application.setClipboardString(text);
	}*/

	public boolean findChanges(String newVersion)
	{
		return (text.equals(newVersion) == false);
	}

	public void share(Context context)
	{
		Intent share = new Intent(android.content.Intent.ACTION_SEND);
		share.setType("text/plain");
		share.putExtra(android.content.Intent.EXTRA_TITLE,
				context.getString(R.string.shareEntityName));
		share.putExtra(android.content.Intent.EXTRA_TEXT, text);
		share.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		context.startActivity(Intent.createChooser(share,
				context.getString(R.string.sharePromptText)));
	}

	public void saveToFile(Context context) throws IOException
	{
		if (TextUtils.isEmpty(fileName) == true)
		{
			fileName = noteManager.createFileName();
		}
		FileOutputStream file = context.openFileOutput(fileName,
				Context.MODE_PRIVATE);



	//	if(getBitmap()!=null){
		//Bitmap bitmapImage = getBitmap();
		//bitmapImage.compress(Bitmap.CompressFormat.PNG, 100, file);}
		//byte [] b=file.toByteArray();
		byte[] buffer = text.getBytes();
		//String temp= Base64.encodeToString(buffer, Base64.DEFAULT);
	//	Uri savedImageURI = Uri.parse(.getAbsolutePath());

			// Display the saved image to ImageView
			//iv_saved.setImageURI(savedImageURI);
		//}
		//byte [] b=file
		file.write(buffer);
		file.flush();
		file.close();

		//if(getBitmap()!=null){
			//saveImage( context,fileName);
		//}
		/*Bitmap bmp = getBitmap(); //BitmapFactory.decodeResource(getResources(), R.drawable.ic_launcher);
		ByteArrayOutputStream stream = new ByteArrayOutputStream();
		bmp.compress(Bitmap.CompressFormat.PNG, 100, file);
		byte[] byteArray = stream.toByteArray();


		ObjectOutputStream objectOutputStream =
				new ObjectOutputStream(new FileOutputStream(fileName));
		objectOutputStream.writeObject(this);
		objectOutputStream.close();*/

	}

	/*public  void saveImage(Context context,String fileName) throws IOException
	{
		FileOutputStream fos = null;
		Bitmap bitmapImage = getBitmap();
		try {
			fos = new FileOutputStream("C:\\Users");
			// Use the compress method on the BitMap object to write image to the OutputStream
			bitmapImage.compress(Bitmap.CompressFormat.PNG, 100, fos);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				fos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		*//*FileOutputStream file = context.openFileOutput(fileName,
				Context.MODE_PRIVATE);
		Bitmap bmp = getBitmap(); //BitmapFactory.decodeResource(getResources(), R.drawable.ic_launcher);
		ByteArrayOutputStream stream = new ByteArrayOutputStream();
		bmp.compress(Bitmap.CompressFormat.PNG, 100, file);
		byte[] byteArray = stream.toByteArray();


		ObjectOutputStream objectOutputStream =
				new ObjectOutputStream(new FileOutputStream(fileName));
		objectOutputStream.writeObject(this);
		objectOutputStream.close();*//*
	}*/
	/**
	 * Loads a note from file // read option
	 * 
	 * @return
	 * @throws IOException
	 */
	public static NoteActions newFromFile(NoteManager noteManager, Context context,
										  String filename) throws IOException {
		FileInputStream inputFileStream = context.openFileInput(filename);
		StringBuilder stringBuilder = new StringBuilder();
		byte[] buffer = new byte[BUFFER_SIZE];
		int len;

		while ((len = inputFileStream.read(buffer)) > 0) {
			String line = new String(buffer, 0, len);
			stringBuilder.append(line);

			buffer = new byte[NoteActions.BUFFER_SIZE];
		}

		//Bitmap b = ((BitmapDrawable)imageView.getDrawable()).getBitmap();//
		//Bitmap b =  BitmapFactory.decodeStream(inputFileStream);
		NoteActions n = new NoteActions(noteManager, stringBuilder.toString().trim(),null);
		n.fileName = filename;
		//ImageView img=(ImageView).findViewById(R.id.viewImage);
		//img.setImageBitmap(b);
		inputFileStream.close();

		return n;
	}


		//	ObjectInputStream objectInputStream =
				//	new ObjectInputStream(new FileInputStream(filename));

			//NoteActions personRead = (NoteActions) objectInputStream.readObject();

			//objectInputStream.close();
			//return personRead;

	
	/*public static NoteActions newFromClipboard(NoteManager noteManager, NotepadApplication application)// me
	{
		CharSequence string = application.getClipboardString();
		if (string == null) return null;
		return new NoteActions(noteManager, string);
	}*/
}
