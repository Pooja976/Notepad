package com.mick88.notepad;

import android.app.Application;


import com.mick88.notepad.NotePad.NoteManager;

public class NotepadApplication extends Application
{
	NoteManager manager = null;
	
	public NotepadApplication() {
	}
	
	@Override
	public void onCreate()
	{
		this.manager = new NoteManager(getApplicationContext());
		super.onCreate();
	}

	public NoteManager getNoteManager()
	{
		return manager;
	}
}
