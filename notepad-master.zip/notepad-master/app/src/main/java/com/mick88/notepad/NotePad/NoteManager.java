package com.mick88.notepad.NotePad;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

//import com.mick88.notepad.NotepadApplication;

import android.content.Context;

/**
 * Contains and manages list of NotePad
 * @author Michal
 *
 */
public class NoteManager
{
	Context context=null;
	ArrayList<NoteActions> noteActions = new ArrayList<NoteActions>();
	
	public NoteManager(Context context) 
	{
		this.context = context;
	}
	
	
	public boolean isEmpty()
	{
		return noteActions.isEmpty();
	}
	
	public int getNumNotes()
	{
		return noteActions.size();
	}
	
	public boolean getNoteByText(String t)
	{
		for (NoteActions n : noteActions) if (n.findChanges(t) == false)
		{
			return true;
		}
		return false;
	}
	
	public boolean getNoteByText(CharSequence text)
	{
		return getNoteByText(text.toString());
	}
	
	public List<NoteActions> getAllNotes()
	{
		return noteActions;
	}
	
	public List<String> getNoteActions()
	{
		ArrayList<String> strings = new ArrayList<String>(noteActions.size());
		for (NoteActions noteActions : this.noteActions) strings.add(noteActions.toString());
		return strings;
	}
	
	public NoteActions getNoteById(int id)
	{
		return noteActions.get(id);
	}
	
	public NoteActions getNoteById(long id)
	{
		return getNoteById((int)id);
	}
	
	/**
	 * Deletes noteActions file and removes it from list
	 * @param noteActions
	 */
	public void deleteNote(NoteActions noteActions)
	{
		noteActions.delete(context);
		this.noteActions.remove(noteActions);
	}
	
	public void deleteNote(int index)
	{
		noteActions.get(index).delete(context);
		noteActions.remove(index);
	}
	
	public void addNote(NoteActions noteActions)
	{
		if (noteActions == null || this.noteActions.contains(noteActions)) return;
		noteActions.noteManager = this;
		this.noteActions.add(noteActions);
		try
		{
			noteActions.saveToFile(context);
		} catch (IOException e)
		{
			e.printStackTrace();
		}
	}
	
	public String createFileName(int ID)
	{
		String name = String.format(Locale.getDefault(), "Note_%d.txt", ID);
		if (context.getFileStreamPath(name).exists() == true) return createFileName(ID+1);
		else return name;
	}
	
	public String createFileName()
	{
		return createFileName(0);
	}

	
	public void loadNotes()
	{
		String[] files = context.fileList();
		noteActions.clear();
		for (String fname:files)
		{
			try
			{
				noteActions.add(NoteActions.newFromFile(this, context, fname));
			} catch (IOException e)
			{
				e.printStackTrace();
			}
		}
		
	}
}
